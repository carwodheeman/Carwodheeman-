import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  products: defineTable({
    name: v.string(),
    price: v.number(),
    description: v.string(),
    quantity: v.number(),
    imageId: v.optional(v.id("_storage")),
    createdBy: v.id("users"),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
