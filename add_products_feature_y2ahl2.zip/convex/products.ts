import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const generateUploadUrl = mutation({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Please login first");
    return await ctx.storage.generateUploadUrl();
  },
});

export const add = mutation({
  args: {
    name: v.string(),
    price: v.number(),
    description: v.string(),
    quantity: v.number(),
    imageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Please login first");
    
    return await ctx.db.insert("products", {
      name: args.name,
      price: args.price,
      description: args.description,
      quantity: args.quantity,
      imageId: args.imageId,
      createdBy: userId,
    });
  },
});

export const remove = mutation({
  args: { productId: v.id("products") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Please login first");
    
    const product = await ctx.db.get(args.productId);
    if (!product) throw new Error("Product not found");
    if (product.createdBy !== userId) throw new Error("Not authorized");
    
    await ctx.db.delete(args.productId);
  },
});

export const list = query({
  handler: async (ctx) => {
    const products = await ctx.db.query("products").order("desc").collect();
    
    return await Promise.all(
      products.map(async (product) => ({
        ...product,
        imageUrl: product.imageId ? await ctx.storage.getUrl(product.imageId) : null,
      }))
    );
  },
});
